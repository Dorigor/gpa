package modelo;

public class Disciplina {
	 private int idDisciplina;
	 private String codDisciplina;
	 private String nomeDisciplina;
	
	 public Disciplina(){
		 /*Construtor vazio*/
	 }
	 
	 
	 /*Construtor completo*/
	 public Disciplina(int idDisciplina, String codDisciplina, String nomeDisciplina){
		 this.idDisciplina = idDisciplina;
		 this.codDisciplina = codDisciplina;
		 this.nomeDisciplina = nomeDisciplina;
	 }
	 
	 /*Construtor sem id*/
	 public Disciplina (String codDisciplina, String nomeDisciplina){
		 this.codDisciplina = codDisciplina;
		 this.nomeDisciplina = nomeDisciplina;		 
	 }
	 
	 public int getIdDisciplina(){
		 return idDisciplina;
	 }
	 
	 public void setIdDisciplina(int idDisciplina){
		 this.idDisciplina = idDisciplina;
	 }
	 
	 public String getCodDisciplina(){
		 return codDisciplina;
	 }
	 
	 public void setCodDisciplina(String codDisciplina){
		 this.codDisciplina = codDisciplina;
	 }
	 
	 public String getNomeDisciplina(){
		 return nomeDisciplina;
	 }
	 
	 public void setNomeDisciplina(String nomeDisciplina){
		 this.nomeDisciplina = nomeDisciplina;
	 }
}
