package modelo;

public class Alternativas {
	private int idQObj; //Chave estranngeira
	private int idAlternativa;
	private String enunAlternativa;
	
	/*Construtor Vazio*/
	public Alternativas(){
		
	}
	
	/*Construtor Completo*/
	public Alternativas(int idQObj, String enunAlternativa, int idAlternativa){
		this.idQObj = idQObj;
		this.enunAlternativa = enunAlternativa;
		this.idAlternativa = idAlternativa;
	}
	
	public int getIdQObj(){
		return idQObj;
	}
	
	public void setIdQObj(int idQObj){
		this.idQObj = idQObj;
	}
	
	public String getEnunAlternativa(){
		return enunAlternativa;
	}
	
	public void setEnunAlternativa(String enunAlternativa){
		this.enunAlternativa = enunAlternativa;
	}
	
	public void setIdAlternativa(int idAlternativa){
		this.idAlternativa = idAlternativa;
	}
	
	public int getIdAlternativa(){
		return idAlternativa;
	}
}
