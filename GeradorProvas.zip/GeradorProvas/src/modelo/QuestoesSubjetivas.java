package modelo;

public class QuestoesSubjetivas {
	private int idQSub;
	private String enunQSub; //Descri��o
	private int difQSub; //Dificuldade
	private int idConteudo; //Chave estrangeira
	
	/*Consrutor vazio*/
	public QuestoesSubjetivas(){
		
	}
	
	/*Construtor completo*/
	public QuestoesSubjetivas(int idQSubj, String enunQSub, int difQSub, int idConteudo){
		this.idQSub = idQSubj;
		this.enunQSub = enunQSub;
		this.difQSub = difQSub;
		this.idConteudo = idConteudo;
	}
	
	/*Construtor sem o idQSub*/
	public QuestoesSubjetivas(String enunQSub, int difQSub, int idConteudo){
		this.enunQSub = enunQSub;
		this.difQSub = difQSub;
		this.idConteudo = idConteudo;
	}
	
	public QuestoesSubjetivas(int idConteudo){
		this.idConteudo = idConteudo;
	}
	
	public QuestoesSubjetivas(int id, String descricao, int dificuldade) {
		this.idQSub = id;
		this.enunQSub = descricao;
		this.difQSub = dificuldade;
	}

	public int getIdQSub(){
		return idQSub;
	}
	
	public void setIdQSub(int idQSub){
		this.idQSub = idQSub;
	}
	
	public String getEnunQSub(){
		return enunQSub;
	}
	
	public void setEnunQSub(String enunQSub){
		this.enunQSub = enunQSub;
	}
	
	public int getDifQSub(){
		return difQSub;
	}
	
	public void setDifQSub(int difQSub){
		this.difQSub = difQSub;
	}
	
	public int getIdConteudo(){
		return idConteudo;
	}
	
	public void setIdConteudo(int idConteudo){
		this.idConteudo = idConteudo;
	}
}
