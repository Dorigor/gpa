package modelo;

public class Conteudo {
	private int idConteudo;
	private String nomeConteudo;
	private int idDisciplina; //Chave estrangeira de Disciplina
	private String disciplina;
	
	public Conteudo(){
		/*Construtor vazio*/
	}
	
	/*Construtor completo*/
	public Conteudo(int idConteudo, String nomeConteudo, int idDisciplina){
		this.idConteudo = idConteudo;
		this.nomeConteudo = nomeConteudo;
		this.idDisciplina = idDisciplina;	
	}
	
	/*Construtor sem o idConteudo*/
	public Conteudo(String nomeConteudo, int idDisciplina){
		this.nomeConteudo = nomeConteudo;
		this.idDisciplina = idDisciplina;
	}
	
	/*Construtor com o nome da disciplina*/
	public Conteudo(int idConteudo, String nomeConteudo, String disciplina){
		this.idConteudo = idConteudo;
		this.nomeConteudo = nomeConteudo;
		this.disciplina = disciplina;	
	}
	
	public Conteudo(int id, String conteudo) {
		this.idConteudo = id;
		this.nomeConteudo = conteudo;
	}

	public void setDisciplina(String disciplina){
		this.disciplina = disciplina;
	}
	
	public String getDisciplina(){
		return disciplina;
	}
	
	public int getIdConteudo(){
		return idConteudo;
	}
	
	public void setIdConteudo(int idConteudo){
		this.idConteudo = idConteudo;
	}
	
	public String getNomeConteudo(){
		return nomeConteudo;
	}
	
	public void setNomeConteudo(String nomeConteudo){
		this.nomeConteudo = nomeConteudo;
	}
	
	public int getIdDisciplina(){
		return idDisciplina;
	}
	
	public void setIdDisciplina(int idDisciplina){
		this.idDisciplina = idDisciplina;
	}
}