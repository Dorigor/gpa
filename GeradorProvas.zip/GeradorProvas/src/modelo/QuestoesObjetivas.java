package modelo;

public class QuestoesObjetivas {
	private int idQObj;
	private String enunQObj;
	private int difQObj;
	private int qtd_alternativas;
	private int idConteudo; //Chave estrangeira
	
	/*Construtor vazio*/
	public QuestoesObjetivas(){
		
	}
	
	public QuestoesObjetivas(int IdQObj){
		this.idQObj = IdQObj;
	}

	/*Construtor completo*/
	public QuestoesObjetivas(int idQObj, String enunQObj, int difQObj, int qtd_alternativas, int idConteudo){
		this.idQObj = idQObj;
		this.enunQObj = enunQObj;
		this.difQObj = difQObj;
		this.idConteudo = idConteudo;
		this.qtd_alternativas = qtd_alternativas;
	}
	
	/*Construtor sem o idQObj*/
	public QuestoesObjetivas(String enunQObj, int difQObj, int qtd_alternativas, int idConteudo){
		this.enunQObj = enunQObj;
		this.difQObj = difQObj;
		this.idConteudo = idConteudo;
		this.qtd_alternativas = qtd_alternativas;
	}
	
	public int getIdQObj(){
		return idQObj;
	}
	
	public void setIdQObj(int idQObj){
		this.idQObj = idQObj;
	}
	
	public String getEnunQObj(){
		return enunQObj;
	}
	
	public void setEnunQObj(String enunQObj){
		this.enunQObj = enunQObj;
	}
	
	public int getDifQObj(){
		return difQObj;
	}
	
	public void setDifQObj(int difQObj){
		this.difQObj = difQObj;
	}
	
	public int getIdConteudo(){
		return idConteudo;
	}
	
	public void setIdConteudo(int idConteudo){
		this.idConteudo = idConteudo;
	}
	

	public void setQtdAlternativas (int qtd_Alternativas){
		this.qtd_alternativas = qtd_Alternativas;
	}

	public int getQtdAlternativas(){
		return qtd_alternativas;
	}
}

