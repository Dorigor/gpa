package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import factory.ConnectionFactory;
import modelo.Disciplina;


public class DisciplinaDAO {

	public void insereDisciplina (Disciplina d) throws SQLException{
		Connection conexao = new ConnectionFactory().getConnection(); //Inicia a conex�o
		String sqlInsereDisciplina = "INSERT INTO DISCIPLINA (CodDisciplina, NomeDisciplina) VALUES (?,?)"; //SQL de inser��o dos dados da disciplina
		PreparedStatement stmtInsereDisciplina = conexao.prepareStatement(sqlInsereDisciplina); // Prepara a instru��o SQL 
		stmtInsereDisciplina.setString(1, d.getCodDisciplina()); //Insere no �ndice 1 (c�digo) o valor informado em CodDisciplina 
		stmtInsereDisciplina.setString(2, d.getNomeDisciplina()); //Insere no �ndice 2 (Nome) o valor informado em NomeDisciplina
		
		stmtInsereDisciplina.executeUpdate(); //Executa a atualiza��o
		stmtInsereDisciplina.close(); //fecha a instru��o
		conexao.close(); //fecha a conex�o com o banco
	}
	
	public void atualizaDisciplina(Disciplina d) throws SQLException{
		Connection conexao = new ConnectionFactory().getConnection();
		String sqlAtualizaDisciplina = "UPDATE DISCIPLINA SET CodDisciplina=?, NomeDisciplina=? Where IdDisciplina=?";
		PreparedStatement stmtAtualizaDisciplina = conexao.prepareStatement(sqlAtualizaDisciplina);
		stmtAtualizaDisciplina.setString(1, d.getCodDisciplina());
		stmtAtualizaDisciplina.setString(2, d.getNomeDisciplina());
		stmtAtualizaDisciplina.setInt(3, d.getIdDisciplina());
		
		stmtAtualizaDisciplina.executeUpdate();
		stmtAtualizaDisciplina.close();
		conexao.close();
	}
	
	public void deletaDisciplina(Disciplina d) throws SQLException{
		Connection conexao = new ConnectionFactory().getConnection();
		String sqlDeletaDisciplina = "DELETE FROM DISCIPLINA WHERE IdDisciplina =?";
		PreparedStatement stmtDeletaDisciplina = conexao.prepareStatement(sqlDeletaDisciplina);
		stmtDeletaDisciplina.setInt(1, d.getIdDisciplina());
		
		stmtDeletaDisciplina.executeUpdate();
		stmtDeletaDisciplina.close();
		conexao.close();
	}
	
	public List<Disciplina> listarDisciplinas() throws SQLException{
		
		ArrayList<Disciplina> lista = new ArrayList<>();
		Connection conexao = new ConnectionFactory().getConnection();
		String sqlListarDisciplinas = "SELECT * FROM DISCIPLINA";
		PreparedStatement stmtListarDiscplinas = conexao.prepareStatement(sqlListarDisciplinas);
		ResultSet rsListarDisciplinas = stmtListarDiscplinas.executeQuery();
		
		while (rsListarDisciplinas.next()){
			int id = rsListarDisciplinas.getInt("IdDisciplina");
			String cod = rsListarDisciplinas.getString("CodDisciplina");
			String nome = rsListarDisciplinas.getString("NomeDisciplina");
			
			Disciplina d = new Disciplina(id, cod, nome);
			
			lista.add(d);
		}
		
		rsListarDisciplinas.close();
		stmtListarDiscplinas.close();
		conexao.close();
		
		return lista;
	}
	
	public Disciplina pegaDisciplina (int IdDisciplina) throws SQLException{
		Disciplina d = null;
		Connection conexao = new ConnectionFactory().getConnection();
		String sqlPegaDisciplina = "SELECT * FROM DISCIPLINA WHERE IdDisciplina = ?";
		PreparedStatement stmtPegaDisciplina = conexao.prepareStatement(sqlPegaDisciplina);
		stmtPegaDisciplina.setInt(1, IdDisciplina);
		ResultSet rsPegaDisciplina = stmtPegaDisciplina.executeQuery();
		
		if(rsPegaDisciplina.next()){
			int id = rsPegaDisciplina.getInt("IdDisciplina");
			String cod = rsPegaDisciplina.getString("CodDisciplina");
			String nome = rsPegaDisciplina.getString("NomeDisciplina");
			
			d = new Disciplina (id, cod, nome);
		}
		rsPegaDisciplina.close();
		stmtPegaDisciplina.close();
		conexao.close();
		
		return d;
	}
}
