package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.QuestoesSubjetivas;
import factory.ConnectionFactory;

public class QuestoesSubjetivasDAO {
	public void insereQuestaoSub(QuestoesSubjetivas q) throws SQLException{
		Connection conexao = new ConnectionFactory().getConnection();
		String sqlInsereQuestao = "INSERT INTO questao_sub (DesQSub, dificuldade, IdConteudo) VALUES(?,?,?)";
		PreparedStatement stmtInsereQuestao = conexao.prepareStatement(sqlInsereQuestao);
		stmtInsereQuestao.setString(1, q.getEnunQSub());
		stmtInsereQuestao.setInt(2, q.getDifQSub());
		stmtInsereQuestao.setInt(3, q.getIdConteudo());
		
		stmtInsereQuestao.executeUpdate();
		stmtInsereQuestao.close();
		conexao.close();
	}
	
	public List<QuestoesSubjetivas> listaQuestoesSubjetivasPorConteudo(int IdConteudo) throws SQLException{
		ArrayList<QuestoesSubjetivas> listaQuestoesSubjtivas = new ArrayList<>();
		Connection conexao = new ConnectionFactory().getConnection();
		String sqlListaQuestoes = "SELECT * FROM questao_sub WHERE IdConteudo=?";
		PreparedStatement stmtListaQuestoes = conexao.prepareStatement(sqlListaQuestoes);
		stmtListaQuestoes.setInt(1, IdConteudo);
		ResultSet rsListaQuestoes = stmtListaQuestoes.executeQuery();
		
		while(rsListaQuestoes.next()){
			int id = rsListaQuestoes.getInt("IdQSub");
			String descricao = rsListaQuestoes.getString("DesQSub");
			int dificuldade = rsListaQuestoes.getInt("dificuldade");
			
			QuestoesSubjetivas qs = new QuestoesSubjetivas(id,descricao,dificuldade);
			
			listaQuestoesSubjtivas.add(qs);
		}
		
		return listaQuestoesSubjtivas;
	}
}
