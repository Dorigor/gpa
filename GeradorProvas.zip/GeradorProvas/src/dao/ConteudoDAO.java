package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.Conteudo;
import factory.ConnectionFactory;

public class ConteudoDAO {
	public void insereConteudo (Conteudo c) throws SQLException{
		Connection conexao = new ConnectionFactory().getConnection();
		String sqlInsereConteudo = "INSERT INTO CONTEUDO (NomeConteudo, IdDisciplina) VALUES(?,?)";
		PreparedStatement stmtInsereConteudo = conexao.prepareStatement(sqlInsereConteudo);
		stmtInsereConteudo.setString(1, c.getNomeConteudo());
		stmtInsereConteudo.setInt(2, c.getIdDisciplina());
		
		stmtInsereConteudo.executeUpdate();
		stmtInsereConteudo.close();
		conexao.close();
	}
	
	public List<Conteudo> listaConteudo() throws SQLException{
		ArrayList<Conteudo> lista= new ArrayList<>();
		Connection conexao = new ConnectionFactory().getConnection();
		String sqlListaConteudo = "select IdConteudo, NomeConteudo, NomeDisciplina from conteudo c, disciplina d where d.IdDisciplina = c.IdDisciplina";
		PreparedStatement stmtListaConteudo = conexao.prepareStatement(sqlListaConteudo);
		ResultSet rsListaConteudo = stmtListaConteudo.executeQuery();
		
		while(rsListaConteudo.next()){
			int cod = rsListaConteudo.getInt("IdConteudo");
			String nome = rsListaConteudo.getString("NomeConteudo");
			String disciplina = rsListaConteudo.getString("NomeDisciplina");
			
			Conteudo c = new Conteudo (cod,nome,disciplina);
			
			lista.add(c);
		}
		
		stmtListaConteudo.close();
		rsListaConteudo.close();
		conexao.close();
		return lista;
	}
	
	public List<Conteudo> listaConteudoDeUmaDisciplina(int IdDisciplina) throws SQLException{
		ArrayList<Conteudo> lista = new ArrayList<>();
		Connection conexao = new ConnectionFactory().getConnection();
		String sqlListaConteudoDeUmaDisciplina = "SELECT IdConteudo, NomeConteudo FROM conteudo c where c.IdDisciplina=?";
		PreparedStatement stmtListaConteudoDeUmaDisciplina = conexao.prepareStatement(sqlListaConteudoDeUmaDisciplina);
		stmtListaConteudoDeUmaDisciplina.setInt(1, IdDisciplina);
		ResultSet rsListaConteudoDeUmaDisciplina = stmtListaConteudoDeUmaDisciplina.executeQuery();
		
		while(rsListaConteudoDeUmaDisciplina.next()){
			int id = rsListaConteudoDeUmaDisciplina.getInt("IdConteudo");
			String conteudo = rsListaConteudoDeUmaDisciplina.getString("NomeConteudo");
			
			Conteudo c = new Conteudo(id, conteudo);
			
			lista.add(c);

		}
		stmtListaConteudoDeUmaDisciplina.close();
		rsListaConteudoDeUmaDisciplina.close();
		conexao.close();
		
		return lista;
	}
}
