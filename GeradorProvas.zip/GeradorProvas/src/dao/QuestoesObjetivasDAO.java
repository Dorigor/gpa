package dao;

import modelo.QuestoesObjetivas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import factory.ConnectionFactory;

public class QuestoesObjetivasDAO {

	public void cadastrarQuestoesObjetivas(QuestoesObjetivas q) throws SQLException{
		Connection conexao = new ConnectionFactory().getConnection();
		String sqlCadastrarQuestoesObjetivas = "INSERT INTO questao_obj (DescQObj, dificuldade, qtd_alternativas, IdConteudo) VALUES (?,?,?,?)";
		PreparedStatement stmtCadastrarQuestoesObjetivas = conexao.prepareStatement(sqlCadastrarQuestoesObjetivas);
		
		stmtCadastrarQuestoesObjetivas.setString(1, q.getEnunQObj());
		stmtCadastrarQuestoesObjetivas.setInt(2, q.getDifQObj());
		stmtCadastrarQuestoesObjetivas.setInt(3, q.getQtdAlternativas());
		stmtCadastrarQuestoesObjetivas.setInt(4, q.getIdConteudo());
		
		stmtCadastrarQuestoesObjetivas.executeUpdate();
		stmtCadastrarQuestoesObjetivas.close();
		conexao.close();
	}
	
	public QuestoesObjetivas pegaUltimaQuestaoObjetiva () throws SQLException{
		QuestoesObjetivas questao = null;
		Connection conexao = new ConnectionFactory().getConnection();
		String sqlPegaUltimaQuestaoObjetiva = "SELECT MAX(IdQObj) FROM questao_obj";
		PreparedStatement stmtPegaUltimaQuestaoObjetiva = conexao.prepareStatement(sqlPegaUltimaQuestaoObjetiva);
		ResultSet rsPegaUltimaQuestaoObjetiva = stmtPegaUltimaQuestaoObjetiva.executeQuery();
		
		while(rsPegaUltimaQuestaoObjetiva.next()){
			int IdQObj = rsPegaUltimaQuestaoObjetiva.getInt("MAX(IdQObj)");
			questao = new QuestoesObjetivas(IdQObj);
		}
		
		rsPegaUltimaQuestaoObjetiva.close();
		stmtPegaUltimaQuestaoObjetiva.close();
		conexao.close();
		
		return questao;
	}
}
