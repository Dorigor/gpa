package dao;

import modelo.Alternativas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import factory.ConnectionFactory;

public class AlternativasDAO {
	
	public void insereAlternativas(Alternativas a) throws SQLException{
		Connection conexao = new ConnectionFactory().getConnection();
		String sqlInsereAlternativa = "INSERT INTO alternativa (DescAlternativa, IdQObj) VALUES (?,?) ";
		PreparedStatement stmtInsereAlternativa = conexao.prepareStatement(sqlInsereAlternativa);		
		
		stmtInsereAlternativa.setString(1, a.getEnunAlternativa());
		stmtInsereAlternativa.setInt(2, a.getIdQObj());
		
		stmtInsereAlternativa.executeUpdate();		
		stmtInsereAlternativa.close();
		conexao.close();		
	}
}
