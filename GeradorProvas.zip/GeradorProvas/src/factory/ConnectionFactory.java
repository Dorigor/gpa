package factory;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
		
public class ConnectionFactory {

	public Connection getConnection() {
		try {
			return DriverManager.getConnection("jdbc:mysql://localhost:3307/geraprova", "root", "1912GNr0");
		}catch(SQLException e){
			throw new RuntimeException(e);
		}
	}
}


