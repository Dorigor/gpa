package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JToolBar;
import javax.xml.crypto.dsig.CanonicalizationMethod;

import org.w3c.dom.ls.LSInput;

import dao.ConteudoDAO;
import dao.DisciplinaDAO;
import dao.QuestoesObjetivasDAO;
import dao.QuestoesSubjetivasDAO;
import dao.AlternativasDAO;

import modelo.Disciplina;
import modelo.Conteudo;
import modelo.QuestoesObjetivas;
import modelo.QuestoesSubjetivas;
import modelo.Alternativas;

import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JMenu;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.CardLayout;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.JSeparator;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JSplitPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.LineNumberInputStream;

import javax.swing.JToggleButton;
import javax.swing.JSpinner;
import javax.swing.JSlider;
import java.awt.Choice;
import javax.swing.JList;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;

public class telaPrincipal {

	private JFrame frame;
	private DefaultTableModel modeloTabelaDisciplinas, modeloTabelaListaDisciplinas, 
	modeloTabelaGerenciarConteudo, modelotabelaConteudoQuestoesSubjetivas, modelotabelaDiscContQuestaoObjetiva, 
	modelotabelaDisciplinaGeraProva, modeloTabelaConteudosGeraProva;
	private JTable tabelaDisciplinas, tabelaListaDisciplinas, tabelaDisciplinasConteudo, 
	tabelaGerenciarConteudo, tabelaConteudoQuestoesSubjetivas, tabelaDisciplinaGeraProva, tabelaConteudosGeraProva;
	private JPanel painelInicial, painelDisciplinaGerenciar, painelDisciplinaCadastrar, painelConteudoCadastrar, 
	painelDisciplinaEditar, painelConteudoGerenciar, painelQuestoesSubjetivasCadastrar, painelQuestoesSubjetivasGerenciar, 
	painelQuestoesObjetivasCadastrar, painelAlternativasCadastrar, painelProvaGerar, painelQuestoesObjetivasGerenciar; 
	JTextField campoNomeDisciplina, campoCodDisciplina;
	JTextArea campoConteudo, campoQuestaoObjetiva, campoDescricaoQuestaoSubjetiva;
	JComboBox comboQuestaoObjetivaDificuldade, comboDificuldadeQSubjetiva;
	
	private int idDisciplina, idDisciplinaEditar, idQuestaoObjetiva, qtdAlternativas;
	private JTextField campoNomeDisciplinaEditar;
	private JTextField campoCodDisciplinaEditar;
	private JTable tabelaDiscContQuestaoObjetiva;
	private JTextField campoQuantidadeAlternativas;
	private JTextField campoQuestoesObjGeraProva;
	private JTextField campoQuestoesSubGeraProva;
	
		
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telaPrincipal window = new telaPrincipal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public telaPrincipal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 631, 460);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new CardLayout(0, 0));
		
		modelotabelaDisciplinaGeraProva = new DefaultTableModel(){
			public boolean isCellEditable(int row, int collumn){
				return false;
			}
		};
		
		modeloTabelaConteudosGeraProva = new DefaultTableModel(){
			public boolean isCellEditable(int row, int collumn){
				return false;
			}
		};
		
		modeloTabelaDisciplinas = new DefaultTableModel(){
			public boolean isCellEditable(int row, int collum){
				return false;
			}
		};
		
		modeloTabelaListaDisciplinas = new DefaultTableModel(){
			public boolean isCellEditable(int row, int collum){
				return false;
			}
		};
		
		modeloTabelaGerenciarConteudo = new DefaultTableModel(){
			public boolean isCellEditable(int row, int collum){
				return false;
			}
		};
		
		modelotabelaDiscContQuestaoObjetiva = new DefaultTableModel(){
			public boolean isCellEditable(int row, int collum){
				return false;
			}
		};
		
		modelotabelaConteudoQuestoesSubjetivas = new DefaultTableModel(){
			public boolean isCellEditable(int row, int collum){
				return false;
			}
		};
		
		//CRIA��O DAS COLUNAS NO MODELO DA TABELA LISTA CONTE�DOS (MENU PROVA)
		modeloTabelaConteudosGeraProva.addColumn("Id");
		modeloTabelaConteudosGeraProva.addColumn("Conte�do");
		
		//CRIA��O DAS COLUNAS NO MODELO DA TABELA LISTA DISCIPLINAS (MENU PROVA)
		modelotabelaDisciplinaGeraProva.addColumn("Id");
		modelotabelaDisciplinaGeraProva.addColumn("Disciplina");
		
		//CRIA��O DAS COLUNAS NO MODELO DA TABELA LISTA DISCIPLINAS (MENU CONTE�DO)
		modeloTabelaListaDisciplinas.addColumn("C�diga");
		modeloTabelaListaDisciplinas.addColumn("Disciplina");
		
		//CRIA��O DAS COLUNAS NO MODELO DA TABELA DISCIPLIINAS
		modeloTabelaDisciplinas.addColumn("Id");
		modeloTabelaDisciplinas.addColumn("C�digo");
		modeloTabelaDisciplinas.addColumn("Disciplina");
		
		//CRIA��O DAS COLUNAS NO MODELO DA TABELA GERENCIAR CONTE�DO
		modeloTabelaGerenciarConteudo.addColumn("IdConte�do");
		modeloTabelaGerenciarConteudo.addColumn("Conte�do");
		modeloTabelaGerenciarConteudo.addColumn("Discipina");
		
		//CRIA��O DAS COLUNAS NO MODELO DA TABELA CADASTRAR QUEST�ES OBJETIVAS (DISICPLINA, CONTE�DO)
		modelotabelaDiscContQuestaoObjetiva.addColumn("IdConte�do");
		modelotabelaDiscContQuestaoObjetiva.addColumn("Conte�do");
		modelotabelaDiscContQuestaoObjetiva.addColumn("Discipina");
		
		//CRIA��O DAS COLUNAS NO MODELO DA TABELA CADASTRAR QUEST�ES SUBJETIVAS (DISCIPLINA, CONTE�DO)
		modelotabelaConteudoQuestoesSubjetivas.addColumn("IdConte�do");
		modelotabelaConteudoQuestoesSubjetivas.addColumn("Conte�do");
		modelotabelaConteudoQuestoesSubjetivas.addColumn("Disciplina");
		
		painelInicial = new JPanel();
		frame.getContentPane().add(painelInicial, "name_1808733080696071");
		painelInicial.setLayout(null);
		
		JLabel lblGeradorDeProvas = new JLabel("Gerador de Provas Aleat\u00F3rias");
		lblGeradorDeProvas.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblGeradorDeProvas.setHorizontalAlignment(SwingConstants.CENTER);
		lblGeradorDeProvas.setBounds(185, 35, 245, 14);
		painelInicial.add(lblGeradorDeProvas);
		
		painelDisciplinaGerenciar = new JPanel();
		frame.getContentPane().add(painelDisciplinaGerenciar, "name_1808696667453981");
		painelDisciplinaGerenciar.setLayout(null);
		
		JLabel lblGerenciarDisciplinas = new JLabel("Gerenciar Disciplinas");
		lblGerenciarDisciplinas.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblGerenciarDisciplinas.setHorizontalAlignment(SwingConstants.CENTER);
		lblGerenciarDisciplinas.setBounds(203, 25, 209, 14);
		painelDisciplinaGerenciar.add(lblGerenciarDisciplinas);
		
		tabelaDisciplinas = new JTable(modeloTabelaDisciplinas);
		tabelaDisciplinas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tabelaDisciplinas.setColumnSelectionAllowed(true);
		tabelaDisciplinas.setBounds(21, 51, 389, 120);
		
		tabelaDisciplinas.getColumnModel().getColumn( 0 ).setMaxWidth( 0 ); //OCULTA A COLUNA DE �NDICE '0', (ID) 
		tabelaDisciplinas.getColumnModel().getColumn( 0 ).setMinWidth( 0 );  
		tabelaDisciplinas.getTableHeader().getColumnModel().getColumn( 0 ).setMaxWidth( 0 );  
		tabelaDisciplinas.getTableHeader().getColumnModel().getColumn( 0 ).setMinWidth( 0 );
		tabelaDisciplinas.getColumnModel().getColumn(1).setPreferredWidth(100);
		tabelaDisciplinas.getColumnModel().getColumn(2).setPreferredWidth(350);
			
		tabelaDisciplinas.setAutoResizeMode(0);
		//Cria��o do scrollpane Discipliinas
		
		JScrollPane scrollDisciplinas = new JScrollPane();
		scrollDisciplinas.setBounds(93, 66, 428, 230);
		scrollDisciplinas.setViewportView(tabelaDisciplinas); //Adi��o da tabela no scrollpane
		painelDisciplinaGerenciar.add(scrollDisciplinas); //Adi��o do scrollpane no painel
		
		JButton botaoDisciplinaEditar = new JButton("Editar");
		botaoDisciplinaEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eEditarDisciplina) {
				int linhaSelecionada = (int) tabelaDisciplinas.getSelectedRow();
							
				if(linhaSelecionada==-1){
					JOptionPane.showMessageDialog(null, "Selcione a disciplina a ser editada","Alerta",JOptionPane.WARNING_MESSAGE);
				}else{
					int opcao = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja editar a disciplina selecionada?", "Confiram��o", JOptionPane.YES_NO_OPTION);
					if(opcao==0){//op��o YES
														
					int IdDiscplina = (int) tabelaDisciplinas.getValueAt(linhaSelecionada, 0);
					DisciplinaDAO dDAO = new DisciplinaDAO();
					try{
						Disciplina d = dDAO.pegaDisciplina(IdDiscplina);
						if(d!=null){
							idDisciplinaEditar = d.getIdDisciplina();
							campoNomeDisciplinaEditar.setText(d.getNomeDisciplina());
							campoCodDisciplinaEditar.setText(d.getCodDisciplina());
						}								
					}catch (SQLException e){
						e.printStackTrace();
						JOptionPane.showMessageDialog(null, "Erro ao editar disciplina", "Ero", JOptionPane.ERROR_MESSAGE);
					}
					/*Pain�is 1*/
						painelInicial.setVisible(false);
						painelConteudoCadastrar.setVisible(false);
						painelConteudoGerenciar.setVisible(false);
						painelDisciplinaCadastrar.setVisible(false);
						painelDisciplinaGerenciar.setVisible(false);
						painelDisciplinaEditar.setVisible(false);
						painelQuestoesSubjetivasCadastrar.setVisible(false);
						painelQuestoesSubjetivasGerenciar.setVisible(false);
						painelAlternativasCadastrar.setVisible(false);
						painelProvaGerar.setVisible(false);
						painelQuestoesObjetivasGerenciar.setVisible(false);
						painelDisciplinaEditar.setVisible(true);
						
					}else{
						painelDisciplinaGerenciar.setVisible(true);
					}
				}
			}
		});
		botaoDisciplinaEditar.setBounds(184, 319, 89, 23);
		painelDisciplinaGerenciar.add(botaoDisciplinaEditar);
		
		JButton botaoDisciplinaDeletar = new JButton("Deletar");
		botaoDisciplinaDeletar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eDeletarDisciplina) {
				int linhaSelecionada = tabelaDisciplinas.getSelectedRow(); //Pega o n�mero da linha selecionada da tabela
				
				if(linhaSelecionada!=-1){
					int opcao = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover a disciplina selecionada?","Confirma��o", JOptionPane.YES_NO_OPTION);
					if (opcao==0){ //op��o YES
						
					int idDisciplina = (int) tabelaDisciplinas.getValueAt(linhaSelecionada, 0); //Pega o n�mero da linha
					Disciplina d = new Disciplina();
					d.setIdDisciplina(idDisciplina);
					
					DisciplinaDAO dDAO = new DisciplinaDAO();
						
					try {
						dDAO.deletaDisciplina(d);
						modeloTabelaDisciplinas.removeRow(linhaSelecionada);
					} catch(SQLException e){
						e.printStackTrace();
					}
				}				
				}else{ //op��o No
					JOptionPane.showMessageDialog(null, "Selecione o aluno a ser deletado", "Alerta", JOptionPane.WARNING_MESSAGE, null);
				}
			}
		});
		botaoDisciplinaDeletar.setBounds(365, 319, 89, 23);
		painelDisciplinaGerenciar.add(botaoDisciplinaDeletar);
		
		painelConteudoCadastrar = new JPanel();
		frame.getContentPane().add(painelConteudoCadastrar);
		painelConteudoCadastrar.setLayout(null);
		
		JLabel lblCadastrarContedos = new JLabel("Cadastrar Conte\u00FAdos");
		lblCadastrarContedos.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblCadastrarContedos.setHorizontalAlignment(SwingConstants.CENTER);
		lblCadastrarContedos.setBounds(186, 23, 243, 14);
		painelConteudoCadastrar.add(lblCadastrarContedos);
		
		JLabel lblSelecioneADisciplina = new JLabel("Selecione a disciplina:");
		lblSelecioneADisciplina.setHorizontalAlignment(SwingConstants.CENTER);
		lblSelecioneADisciplina.setBounds(363, 84, 127, 14);
		painelConteudoCadastrar.add(lblSelecioneADisciplina);
		
		JScrollPane scrollConteudo = new JScrollPane();
		scrollConteudo.setBounds(43, 109, 203, 63);
		painelConteudoCadastrar.add(scrollConteudo);
		
		JLabel lblContedo = new JLabel("Conte\u00FAdo:");
		scrollConteudo.setColumnHeaderView(lblContedo);
		
		campoConteudo = new JTextArea();
		scrollConteudo.setViewportView(campoConteudo);
		campoConteudo.setLineWrap(true);
		
		JScrollPane scrollSelecaoDisciplina = new JScrollPane();
		scrollSelecaoDisciplina.setBounds(293, 109, 269, 162);
		painelConteudoCadastrar.add(scrollSelecaoDisciplina);
		
		tabelaDisciplinasConteudo = new JTable(modeloTabelaListaDisciplinas);
		scrollSelecaoDisciplina.setViewportView(tabelaDisciplinasConteudo);
		
		tabelaDisciplinasConteudo.getColumnModel().getColumn(0).setMaxWidth(0);
		tabelaDisciplinasConteudo.getColumnModel().getColumn(0).setMinWidth(0);
		tabelaDisciplinasConteudo.getTableHeader().getColumnModel().getColumn( 0 ).setMaxWidth( 0 );  
		tabelaDisciplinasConteudo.getTableHeader().getColumnModel().getColumn( 0 ).setMinWidth( 0 );
		tabelaDisciplinasConteudo.getColumnModel().getColumn(1).setPreferredWidth(300);
		tabelaDisciplinasConteudo.setAutoResizeMode(0);
		
		JButton btnLimparConteudo = new JButton("Limpar");
		btnLimparConteudo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eLimparConteudo) {
				campoConteudo.setText("");
				campoConteudo.requestFocus();
			}
		});
		
		btnLimparConteudo.setBounds(43, 248, 89, 23);
		painelConteudoCadastrar.add(btnLimparConteudo);
		
		JButton btnCadastrar = new JButton("Cadastrar");
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eCadastrarConteudo) {
				campoConteudo.requestFocus();
				String nomeConteudo = campoConteudo.getText(); 
				int linhaSelecionada = tabelaDisciplinasConteudo.getSelectedRow();
				
				if(nomeConteudo.isEmpty() || (!tabelaDisciplinasConteudo.isColumnSelected(1))){ //Verifica se o usu�rio digitou no campo Descri��o do conte�do e se ele selecionou alguma disciplina
					JOptionPane.showMessageDialog(null, "Campos obrigat�rios!","Aten��o",JOptionPane.WARNING_MESSAGE);
					return;
				}else{
					int idDisciplinas = (int) tabelaDisciplinasConteudo.getValueAt(linhaSelecionada, 0);
					Conteudo c = new Conteudo();
					ConteudoDAO cDAO = new ConteudoDAO();
					
					c.setIdDisciplina(idDisciplinas);
					c.setNomeConteudo(nomeConteudo);
					
					try {
						cDAO.insereConteudo(c);
						JOptionPane.showMessageDialog(null, "Conte�do cadastrado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
					} catch (SQLException e) {
						JOptionPane.showMessageDialog(null, "Erro ao cadastrar o conte�do. Contate o administrador do Sistema", "Erro", JOptionPane.ERROR_MESSAGE);
						e.printStackTrace();
					}
				}						
			}
		});
		
		btnCadastrar.setBounds(151, 248, 95, 23);
		painelConteudoCadastrar.add(btnCadastrar);
		
		painelDisciplinaCadastrar = new JPanel();
		frame.getContentPane().add(painelDisciplinaCadastrar, "name_1808696656197080");
		painelDisciplinaCadastrar.setLayout(null);
		
		JLabel lblAdicionarDisciplina = new JLabel("Cadastrar Disciplina");
		lblAdicionarDisciplina.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdicionarDisciplina.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblAdicionarDisciplina.setBounds(215, 29, 184, 30);
		painelDisciplinaCadastrar.add(lblAdicionarDisciplina);
		
		JLabel txtNomeDiscplina = new JLabel("Nome da Disciplina:");
		txtNomeDiscplina.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtNomeDiscplina.setBounds(99, 99, 135, 23);
		painelDisciplinaCadastrar.add(txtNomeDiscplina);
		
		JLabel txtCodDisciplina = new JLabel("C\u00F3digo da Disciplina:");
		txtCodDisciplina.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtCodDisciplina.setBounds(99, 150, 135, 23);
		painelDisciplinaCadastrar.add(txtCodDisciplina);
		
		campoNomeDisciplina = new JTextField();
		campoNomeDisciplina.setBounds(240, 99, 273, 22);
		painelDisciplinaCadastrar.add(campoNomeDisciplina);
		
		campoCodDisciplina = new JTextField();
		campoCodDisciplina.setBounds(240, 150, 102, 22);
		painelDisciplinaCadastrar.add(campoCodDisciplina);
		
		JButton botaoDisciplinaCadastrar = new JButton("Cadastrar");
		botaoDisciplinaCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eventoDisciplinaADD) {
				
				// Pega as vari�veis inseridas no campo de nome e c�digo da disciplina
				String codigoDiscplina = campoCodDisciplina.getText();
				String nomeDisciplina = campoNomeDisciplina.getText();
				
				// Obrigando a cadastrar o nome e o c�digo da disciplina
				
				if (nomeDisciplina.isEmpty() || codigoDiscplina.isEmpty()){
					JOptionPane.showMessageDialog(null, "Campos obrigat�rios n�o preenchidos!", "Aten��o", JOptionPane.WARNING_MESSAGE);
				}
				else{
					Disciplina a = new Disciplina(codigoDiscplina, nomeDisciplina);
					DisciplinaDAO aDAO = new DisciplinaDAO();
					try{
						aDAO.insereDisciplina(a);
						JOptionPane.showMessageDialog(null, "Disciplina cadastrada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
						campoNomeDisciplina.setText("");
						campoCodDisciplina.setText("");
						campoNomeDisciplina.requestFocus();
					}catch (SQLException e){
						JOptionPane.showMessageDialog(null, "Erro de Inser��o ao banco de dados. Consulte o administrador", "Erro de inser��o", JOptionPane.ERROR_MESSAGE, null);
						e.printStackTrace();
						return;
					}
				}				
			}
		});
		botaoDisciplinaCadastrar.setBounds(175, 227, 102, 23);
		painelDisciplinaCadastrar.add(botaoDisciplinaCadastrar);
		
		JButton btnLimpar_1 = new JButton("Limpar");
		btnLimpar_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eLimparCadastroDisciplina) {
				campoNomeDisciplina.setText("");
				campoCodDisciplina.setText("");
				campoNomeDisciplina.requestFocus();
			}
		});
		btnLimpar_1.setBounds(353, 227, 89, 23);
		painelDisciplinaCadastrar.add(btnLimpar_1);
		
		painelDisciplinaEditar = new JPanel();
		frame.getContentPane().add(painelDisciplinaEditar, "name_94188446425089");
		painelDisciplinaEditar.setLayout(null);
		
		JLabel lblNomeDisciplinaEditar = new JLabel("Nome da Disciplina:");
		lblNomeDisciplinaEditar.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNomeDisciplinaEditar.setBounds(78, 100, 135, 23);
		painelDisciplinaEditar.add(lblNomeDisciplinaEditar);
		
		campoNomeDisciplinaEditar = new JTextField();
		campoNomeDisciplinaEditar.setBounds(219, 100, 310, 22);
		painelDisciplinaEditar.add(campoNomeDisciplinaEditar);
		
		JLabel lblCodDisciplinaEditar = new JLabel("C\u00F3digo da Disciplina:");
		lblCodDisciplinaEditar.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblCodDisciplinaEditar.setBounds(78, 156, 135, 23);
		painelDisciplinaEditar.add(lblCodDisciplinaEditar);
		
		campoCodDisciplinaEditar = new JTextField();
		campoCodDisciplinaEditar.setBounds(219, 156, 102, 22);
		painelDisciplinaEditar.add(campoCodDisciplinaEditar);
		
		/*Bot�o Atualizar Disciplina - Painel Editar Disciplina*/
		JButton botaoAtualizarDisciplina = new JButton("Atualizar");
		botaoAtualizarDisciplina.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				campoNomeDisciplinaEditar.requestFocus(); //Foca o cursos no campo Nome
				String cod = campoCodDisciplinaEditar.getText(); //Pega as novas informa��es do campo 'CodDisciplina'
				String nome = campoNomeDisciplinaEditar.getText(); //Pega as novas informa��es do campo 'NomeDisciplina'
				
				if((nome.isEmpty()) || (cod.isEmpty())){//Verifica se os campos Nome e C�digo est�o vazios
					JOptionPane.showMessageDialog(null, "Campos obrigat�rios!", "Aten��o", JOptionPane.WARNING_MESSAGE);
					return; //retorna para o in�cio do m�todo
				}
				Disciplina d = new Disciplina(idDisciplinaEditar, cod, nome); //Cria um objeto Disciplina com o ID da disciplina que est� sendo editada, o novo cod e o novo nome
				DisciplinaDAO dDAO = new DisciplinaDAO(); //Cria um objeto do tipo dDAO
				
				try{
					dDAO.atualizaDisciplina(d); //Atualiza disciplina no BD
					
					/*Pain�is 2*/
					painelInicial.setVisible(false);
					painelConteudoCadastrar.setVisible(false);
					painelConteudoGerenciar.setVisible(false);
					painelQuestoesSubjetivasCadastrar.setVisible(false);
					painelQuestoesSubjetivasGerenciar.setVisible(false);
					painelQuestoesObjetivasCadastrar.setVisible(false);
					painelDisciplinaEditar.setVisible(false);
					painelDisciplinaCadastrar.setVisible(false);
					painelAlternativasCadastrar.setVisible(false);
					painelProvaGerar.setVisible(false);
					painelQuestoesObjetivasGerenciar.setVisible(false);
					painelDisciplinaGerenciar.setVisible(true);
					
					//limpar tabela inteira
					modeloTabelaDisciplinas.getDataVector().removeAllElements();
										
					//Pegar disciplinas do BD
					List<Disciplina> listaDisciplinas = new ArrayList<Disciplina>();
					
					try{
						listaDisciplinas = dDAO.listarDisciplinas(); //adiciona na listaDisciplinas 
						for (Disciplina f: listaDisciplinas){
							modeloTabelaDisciplinas.addRow(new Object[] {f.getIdDisciplina(), f.getCodDisciplina(), f.getNomeDisciplina()}); //adiciona 
						}
					}catch(SQLException b){
						b.printStackTrace();
						JOptionPane.showMessageDialog(null, "Erro no Banco de Dados. Contate o administrador do sistema", "Erro", JOptionPane.ERROR_MESSAGE);
					}
					JOptionPane.showMessageDialog(null, "Disciplina atualizada com sucesso!","Sucesso",JOptionPane.INFORMATION_MESSAGE);
					
				}catch(SQLException e1){
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null, "Erro no Banco de Dados. Contate o administrador do sistema", "Erro", JOptionPane.ERROR_MESSAGE);
				}
				/*Pain�is 3*/
				painelInicial.setVisible(false);
				painelConteudoCadastrar.setVisible(false);
				painelConteudoGerenciar.setVisible(false);
				painelDisciplinaEditar.setVisible(false);
				painelDisciplinaCadastrar.setVisible(false);
				painelQuestoesSubjetivasCadastrar.setVisible(false);
				painelQuestoesSubjetivasGerenciar.setVisible(false);
				painelQuestoesObjetivasCadastrar.setVisible(false);
				painelAlternativasCadastrar.setVisible(false);
				painelProvaGerar.setVisible(false);
				painelQuestoesObjetivasGerenciar.setVisible(false);
				painelDisciplinaGerenciar.setVisible(true);
			}
		});
		botaoAtualizarDisciplina.setBounds(170, 229, 102, 23);
		painelDisciplinaEditar.add(botaoAtualizarDisciplina);
		
		JButton botaoLimparDisciplinaEditar = new JButton("Limpar");
		botaoLimparDisciplinaEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eLimparEditarDisciplina) {
				campoCodDisciplinaEditar.setText("");
				campoNomeDisciplinaEditar.setText("");
				campoNomeDisciplinaEditar.requestFocus();
			}
		});
		botaoLimparDisciplinaEditar.setBounds(348, 229, 89, 23);
		painelDisciplinaEditar.add(botaoLimparDisciplinaEditar);
		
		JLabel lblEditarDisciplina = new JLabel("Editar Disciplina");
		lblEditarDisciplina.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblEditarDisciplina.setHorizontalAlignment(SwingConstants.CENTER);
		lblEditarDisciplina.setBounds(221, 26, 173, 14);
		painelDisciplinaEditar.add(lblEditarDisciplina);
		
		painelConteudoGerenciar = new JPanel();
		frame.getContentPane().add(painelConteudoGerenciar, "name_224732084955154");
		painelConteudoGerenciar.setLayout(null);
		
		JLabel lblGerenciarContedo = new JLabel("Gerenciar Conte\u00FAdos");
		lblGerenciarContedo.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblGerenciarContedo.setHorizontalAlignment(SwingConstants.CENTER);
		lblGerenciarContedo.setBounds(209, 21, 197, 14);
		painelConteudoGerenciar.add(lblGerenciarContedo);
		
		JScrollPane scrollGerenciarConteudo = new JScrollPane();
		scrollGerenciarConteudo.setBounds(103, 58, 409, 261);
		painelConteudoGerenciar.add(scrollGerenciarConteudo);
		
		tabelaGerenciarConteudo = new JTable(modeloTabelaGerenciarConteudo);
		scrollGerenciarConteudo.setViewportView(tabelaGerenciarConteudo);
		
		tabelaGerenciarConteudo.getColumnModel().getColumn( 0 ).setMaxWidth( 0 ); //OCULTA A COLUNA DE �NDICE '0', (ID) 
		tabelaGerenciarConteudo.getColumnModel().getColumn( 0 ).setMinWidth( 0 );  
		tabelaGerenciarConteudo.getTableHeader().getColumnModel().getColumn( 0 ).setMaxWidth( 0 );  
		tabelaGerenciarConteudo.getTableHeader().getColumnModel().getColumn( 0 ).setMinWidth( 0 );
		tabelaGerenciarConteudo.getColumnModel().getColumn(1).setPreferredWidth(200);
		tabelaGerenciarConteudo.getColumnModel().getColumn(2).setPreferredWidth(300);
		tabelaGerenciarConteudo.setAutoResizeMode(0);
			
		JButton btnEditarConteudo = new JButton("Editar");
		btnEditarConteudo.setBounds(161, 339, 89, 23);
		painelConteudoGerenciar.add(btnEditarConteudo);
		
		JButton btnDeletarConteudo = new JButton("Deletar");
		btnDeletarConteudo.setBounds(349, 339, 89, 23);
		painelConteudoGerenciar.add(btnDeletarConteudo);
		
		painelQuestoesSubjetivasCadastrar = new JPanel();
		frame.getContentPane().add(painelQuestoesSubjetivasCadastrar, "name_577582315858345");
		painelQuestoesSubjetivasCadastrar.setLayout(null);
		
		JLabel lblCadastrarQuestesSubjetivas = new JLabel("Cadastrar Quest\u00F5es Subjetivas");
		lblCadastrarQuestesSubjetivas.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblCadastrarQuestesSubjetivas.setHorizontalAlignment(SwingConstants.CENTER);
		lblCadastrarQuestesSubjetivas.setBounds(156, 25, 301, 14);
		painelQuestoesSubjetivasCadastrar.add(lblCadastrarQuestesSubjetivas);
		
		JScrollPane scrollQuestaoSubjetiva = new JScrollPane();
		scrollQuestaoSubjetiva.setBounds(45, 76, 237, 182);
		painelQuestoesSubjetivasCadastrar.add(scrollQuestaoSubjetiva);
		
		campoDescricaoQuestaoSubjetiva = new JTextArea();
		campoDescricaoQuestaoSubjetiva.setWrapStyleWord(true);
		campoDescricaoQuestaoSubjetiva.setLineWrap(true);
		scrollQuestaoSubjetiva.setViewportView(campoDescricaoQuestaoSubjetiva);
		
		JLabel lblDescrio = new JLabel("Descri\u00E7\u00E3o:");
		lblDescrio.setHorizontalAlignment(SwingConstants.LEFT);
		scrollQuestaoSubjetiva.setColumnHeaderView(lblDescrio);
		
		JButton botaoCadastrarQuestaoSubjetiva = new JButton("Cadastrar");
		botaoCadastrarQuestaoSubjetiva.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eventoCadastrarQSub) {
				String descQuestaoSubjetiva = campoDescricaoQuestaoSubjetiva.getText();
				int dificuldadeQuestaoSubjetiva = comboDificuldadeQSubjetiva.getSelectedIndex();
				int linhaSelecionada = (int) tabelaConteudoQuestoesSubjetivas.getSelectedRow();
				
				int IdConteudo = (int) tabelaConteudoQuestoesSubjetivas.getValueAt(linhaSelecionada, 0);
				
				QuestoesSubjetivas qs = new QuestoesSubjetivas();
				
				QuestoesSubjetivasDAO qsDAO = new QuestoesSubjetivasDAO();
				qs.setEnunQSub(descQuestaoSubjetiva);
				qs.setDifQSub(dificuldadeQuestaoSubjetiva);
				qs.setIdConteudo(IdConteudo);
				
				try{
					qsDAO.insereQuestaoSub(qs);
					JOptionPane.showMessageDialog(null, "Quest�o cadastrada com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
					campoDescricaoQuestaoSubjetiva.setText("");
				}catch(SQLException e){
					e.printStackTrace();
				}				
			}
		});
		botaoCadastrarQuestaoSubjetiva.setBounds(201, 341, 101, 23);
		painelQuestoesSubjetivasCadastrar.add(botaoCadastrarQuestaoSubjetiva);
		
		JButton botaoLimparQuestaoSubjetiva = new JButton("Limpar");
		botaoLimparQuestaoSubjetiva.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eventoLimparDescQSub) {
				campoDescricaoQuestaoSubjetiva.setText("");
				campoDescricaoQuestaoSubjetiva.requestFocus();
			}
		});
		botaoLimparQuestaoSubjetiva.setBounds(368, 341, 90, 23);
		painelQuestoesSubjetivasCadastrar.add(botaoLimparQuestaoSubjetiva);
		
		comboDificuldadeQSubjetiva = new JComboBox();
		comboDificuldadeQSubjetiva.setModel(new DefaultComboBoxModel(new String[] {"F\u00E1cil", "M\u00E9dio", "Dif\u00EDcil"}));
		comboDificuldadeQSubjetiva.setSelectedIndex(0);
		comboDificuldadeQSubjetiva.setBounds(59, 304, 114, 23);
		painelQuestoesSubjetivasCadastrar.add(comboDificuldadeQSubjetiva);
		
		JLabel lblDificuldade = new JLabel("Dificuldade:");
		lblDificuldade.setHorizontalAlignment(SwingConstants.CENTER);
		lblDificuldade.setBounds(59, 279, 71, 14);
		painelQuestoesSubjetivasCadastrar.add(lblDificuldade);
		
		JScrollPane scrollConteudosQuestoesSub = new JScrollPane();
		scrollConteudosQuestoesSub.setBounds(311, 76, 269, 182);
		painelQuestoesSubjetivasCadastrar.add(scrollConteudosQuestoesSub);
		
		tabelaConteudoQuestoesSubjetivas = new JTable(modelotabelaConteudoQuestoesSubjetivas);
		scrollConteudosQuestoesSub.setViewportView(tabelaConteudoQuestoesSubjetivas);
		
		tabelaConteudoQuestoesSubjetivas.getColumnModel().getColumn( 0 ).setMaxWidth( 0 ); //OCULTA A COLUNA DE �NDICE '0', (ID) 
		tabelaConteudoQuestoesSubjetivas.getColumnModel().getColumn( 0 ).setMinWidth( 0 );  
		tabelaConteudoQuestoesSubjetivas.getTableHeader().getColumnModel().getColumn( 0 ).setMaxWidth( 0 );  
		tabelaConteudoQuestoesSubjetivas.getTableHeader().getColumnModel().getColumn( 0 ).setMinWidth( 0 );
		tabelaConteudoQuestoesSubjetivas.getColumnModel().getColumn(1).setPreferredWidth(200);
		tabelaConteudoQuestoesSubjetivas.getColumnModel().getColumn(2).setPreferredWidth(350);
		
		tabelaConteudoQuestoesSubjetivas.setAutoResizeMode(0);
		
		painelQuestoesSubjetivasGerenciar = new JPanel();
		frame.getContentPane().add(painelQuestoesSubjetivasGerenciar, "name_578750981972664");
		painelQuestoesSubjetivasGerenciar.setLayout(null);
		
		JLabel lblGerenciarQuestesSubjetivas = new JLabel("Gerenciar Quest\u00F5es Subjetivas");
		lblGerenciarQuestesSubjetivas.setHorizontalAlignment(SwingConstants.CENTER);
		lblGerenciarQuestesSubjetivas.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblGerenciarQuestesSubjetivas.setBounds(167, 41, 281, 14);
		painelQuestoesSubjetivasGerenciar.add(lblGerenciarQuestesSubjetivas);
		
		painelQuestoesObjetivasCadastrar = new JPanel();
		frame.getContentPane().add(painelQuestoesObjetivasCadastrar, "name_128180302981559");
		painelQuestoesObjetivasCadastrar.setLayout(null);
		
		JLabel lblCadastrarQuestesObjetivas = new JLabel("Cadastrar Quest\u00F5es Objetivas");
		lblCadastrarQuestesObjetivas.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblCadastrarQuestesObjetivas.setHorizontalAlignment(SwingConstants.CENTER);
		lblCadastrarQuestesObjetivas.setBounds(157, 30, 300, 14);
		painelQuestoesObjetivasCadastrar.add(lblCadastrarQuestesObjetivas);
		
		JScrollPane scrollDiscConQuestaoObjetiva = new JScrollPane();
		scrollDiscConQuestaoObjetiva.setBounds(315, 81, 273, 179);
		painelQuestoesObjetivasCadastrar.add(scrollDiscConQuestaoObjetiva);
		
		tabelaDiscContQuestaoObjetiva = new JTable(modelotabelaDiscContQuestaoObjetiva);
		scrollDiscConQuestaoObjetiva.setViewportView(tabelaDiscContQuestaoObjetiva);
		
		tabelaDiscContQuestaoObjetiva.getColumnModel().getColumn( 0 ).setMaxWidth( 0 ); //OCULTA A COLUNA DE �NDICE '0', (ID) 
		tabelaDiscContQuestaoObjetiva.getColumnModel().getColumn( 0 ).setMinWidth( 0 );  
		tabelaDiscContQuestaoObjetiva.getTableHeader().getColumnModel().getColumn( 0 ).setMaxWidth( 0 );  
		tabelaDiscContQuestaoObjetiva.getTableHeader().getColumnModel().getColumn( 0 ).setMinWidth( 0 );
		tabelaDiscContQuestaoObjetiva.getColumnModel().getColumn(1).setPreferredWidth(200);
		tabelaDiscContQuestaoObjetiva.getColumnModel().getColumn(2).setPreferredWidth(300);
		tabelaDiscContQuestaoObjetiva.setAutoResizeMode(0);
		
		JLabel lblDificuldade_1 = new JLabel("Dificuldade:");
		lblDificuldade_1.setBounds(53, 280, 87, 14);
		painelQuestoesObjetivasCadastrar.add(lblDificuldade_1);
		
		comboQuestaoObjetivaDificuldade = new JComboBox();
		comboQuestaoObjetivaDificuldade.setModel(new DefaultComboBoxModel(new String[] {"F\u00E1cil", "M\u00E9dio", "Dif\u00EDcil"}));
		comboQuestaoObjetivaDificuldade.setBounds(53, 303, 94, 20);
		painelQuestoesObjetivasCadastrar.add(comboQuestaoObjetivaDificuldade);
		
		JLabel lblQuantidadeDeAlternativas = new JLabel("Quantidade de Alternativas:");
		lblQuantidadeDeAlternativas.setBounds(315, 280, 177, 14);
		painelQuestoesObjetivasCadastrar.add(lblQuantidadeDeAlternativas);
		
		campoQuantidadeAlternativas = new JTextField();
		campoQuantidadeAlternativas.setHorizontalAlignment(SwingConstants.CENTER);
		campoQuantidadeAlternativas.setText("05");
		campoQuantidadeAlternativas.setBounds(315, 303, 57, 20);
		painelQuestoesObjetivasCadastrar.add(campoQuantidadeAlternativas);
		campoQuantidadeAlternativas.setColumns(10);
		
		/*Bot�o QObj -> Cadastrar*/
		JButton botaoCadastrarQuestoesObjetivas = new JButton("Cadastrar");
		botaoCadastrarQuestoesObjetivas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eCadastrarQObj) {
				String descQuestaoObjetiva = campoQuestaoObjetiva.getText();
				int dificuldadeQuestaoObjetiva = comboQuestaoObjetivaDificuldade.getSelectedIndex();
				int linhaSelecionada = tabelaDiscContQuestaoObjetiva.getSelectedRow();
				qtdAlternativas = Integer.parseInt(campoQuantidadeAlternativas.getText());
				
				int IdConteudo = (int) tabelaDiscContQuestaoObjetiva.getValueAt(linhaSelecionada,0);
				
				QuestoesObjetivas q = new QuestoesObjetivas();
				
				QuestoesObjetivasDAO qObjDAO = new QuestoesObjetivasDAO();
				
				q.setEnunQObj(descQuestaoObjetiva);
				q.setDifQObj(dificuldadeQuestaoObjetiva);
				q.setIdConteudo(IdConteudo);
				q.setQtdAlternativas(qtdAlternativas);
				
				try {
					qObjDAO.cadastrarQuestoesObjetivas(q);
					
					QuestoesObjetivas questao = qObjDAO.pegaUltimaQuestaoObjetiva();
					idQuestaoObjetiva = questao.getIdQObj();
					
					JOptionPane.showMessageDialog(null, "Quest�o cadastrada com suceeso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
					JOptionPane.showMessageDialog(null, "Agora, cadastre as alternativas.", "Aten��o", JOptionPane.WARNING_MESSAGE);
					
					/*Pain�is 4*/
						painelInicial.setVisible(false);
						painelDisciplinaCadastrar.setVisible(false);
						painelDisciplinaGerenciar.setVisible(false);
						painelDisciplinaEditar.setVisible(false);
						painelConteudoCadastrar.setVisible(false);
						painelConteudoGerenciar.setVisible(false);
						painelQuestoesSubjetivasCadastrar.setVisible(false);
						painelQuestoesSubjetivasGerenciar.setVisible(false);
						painelQuestoesObjetivasCadastrar.setVisible(false);
						painelProvaGerar.setVisible(false);
						painelQuestoesObjetivasGerenciar.setVisible(false);
						painelAlternativasCadastrar.setVisible(true);
					
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		});
		botaoCadastrarQuestoesObjetivas.setBounds(157, 349, 111, 23);
		painelQuestoesObjetivasCadastrar.add(botaoCadastrarQuestoesObjetivas);
		
		JButton botaoLimparQuestoesObjetivas = new JButton("Limpar");
		botaoLimparQuestoesObjetivas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eLimparQObj) {
				campoQuestaoObjetiva.setText("");
				campoQuestaoObjetiva.requestFocus();
			}
		});
		botaoLimparQuestoesObjetivas.setBounds(344, 349, 100, 23);
		painelQuestoesObjetivasCadastrar.add(botaoLimparQuestoesObjetivas);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(41, 81, 241, 179);
		painelQuestoesObjetivasCadastrar.add(scrollPane);
		
		campoQuestaoObjetiva = new JTextArea();
		scrollPane.setViewportView(campoQuestaoObjetiva);
		campoQuestaoObjetiva.setWrapStyleWord(true);
		campoQuestaoObjetiva.setLineWrap(true);
		
		JLabel lblDescricao = new JLabel("Descri\u00E7\u00E3o:");
		scrollPane.setColumnHeaderView(lblDescricao);
		
		painelAlternativasCadastrar = new JPanel();
		frame.getContentPane().add(painelAlternativasCadastrar, "name_128729119143897");
		painelAlternativasCadastrar.setLayout(null);
		
		JLabel lblCadastrarAlternativas = new JLabel("Cadastrar Alternativas");
		lblCadastrarAlternativas.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblCadastrarAlternativas.setHorizontalAlignment(SwingConstants.CENTER);
		lblCadastrarAlternativas.setBounds(171, 46, 272, 14);
		painelAlternativasCadastrar.add(lblCadastrarAlternativas);
		
		JLabel lblAlternativa = new JLabel("Alternativa:");
		lblAlternativa.setBounds(68, 112, 86, 14);
		painelAlternativasCadastrar.add(lblAlternativa);
		
		JScrollPane scrollCadastrarAlternativa = new JScrollPane();
		scrollCadastrarAlternativa.setBounds(154, 112, 331, 155);
		painelAlternativasCadastrar.add(scrollCadastrarAlternativa);
		
		JTextArea campoCadastrarAlternativa = new JTextArea();
		scrollCadastrarAlternativa.setViewportView(campoCadastrarAlternativa);
					
		JButton botaoCadastrarAlternativa = new JButton("Cadastrar");
		botaoCadastrarAlternativa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eventoCadastrarAlternativa) {
				
				campoCadastrarAlternativa.requestFocus();	
				QuestoesObjetivas qObj = new QuestoesObjetivas();
				
				String DescAlternativa = campoCadastrarAlternativa.getText();
				
				Alternativas a = new Alternativas();
				
				a.setEnunAlternativa(DescAlternativa);
				a.setIdQObj(idQuestaoObjetiva);
				
				try{
					AlternativasDAO aDAO = new AlternativasDAO();
					aDAO.insereAlternativas(a);
					
					int teste = JOptionPane.showConfirmDialog(null, "Deseja continuar a cadastrar?", "Alternativa cadastrada com sucesso!",JOptionPane.OK_OPTION);
					
					if (teste==0){
						campoCadastrarAlternativa.setText("");
					}
					
					if(teste==1){
						/*Pain�is 5*/
						painelAlternativasCadastrar.setVisible(false);
						painelConteudoCadastrar.setVisible(false);
						painelConteudoGerenciar.setVisible(false);
						painelDisciplinaCadastrar.setVisible(false);
						painelDisciplinaEditar.setVisible(false);
						painelDisciplinaGerenciar.setVisible(false);
						painelQuestoesObjetivasCadastrar.setVisible(false);
						painelQuestoesSubjetivasCadastrar.setVisible(false);
						painelQuestoesSubjetivasGerenciar.setVisible(false);
						painelProvaGerar.setVisible(false);
						painelQuestoesObjetivasGerenciar.setVisible(false);
						painelInicial.setVisible(true);
					}
					
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		});
		
		botaoCadastrarAlternativa.setBounds(193, 308, 96, 23);
		painelAlternativasCadastrar.add(botaoCadastrarAlternativa);
		
		JButton botaoLimparAlternativa = new JButton("Limpar");
		botaoLimparAlternativa.setBounds(353, 308, 89, 23);
		painelAlternativasCadastrar.add(botaoLimparAlternativa);
		
		painelProvaGerar = new JPanel();
		frame.getContentPane().add(painelProvaGerar, "name_553834591149089");
		painelProvaGerar.setLayout(null);
		
		JLabel lblGerarProvasAleatrias = new JLabel("Gerar Provas Aleat\u00F3rias");
		lblGerarProvasAleatrias.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblGerarProvasAleatrias.setHorizontalAlignment(SwingConstants.CENTER);
		lblGerarProvasAleatrias.setBounds(171, 22, 272, 14);
		painelProvaGerar.add(lblGerarProvasAleatrias);
		
		JLabel lblSelecioneADisciplina_1 = new JLabel("Selecione a disciplina:");
		lblSelecioneADisciplina_1.setBounds(38, 70, 149, 14);
		painelProvaGerar.add(lblSelecioneADisciplina_1);
		
		JScrollPane scrollDisciplinaGeraProva = new JScrollPane();
		
		scrollDisciplinaGeraProva.setBounds(38, 95, 247, 149);
		painelProvaGerar.add(scrollDisciplinaGeraProva);
				
		tabelaDisciplinaGeraProva = new JTable(modelotabelaDisciplinaGeraProva);
		tabelaDisciplinaGeraProva.getColumnModel().getColumn(0).setMaxWidth(0);
		tabelaDisciplinaGeraProva.getColumnModel().getColumn(0).setMinWidth(0);
		tabelaDisciplinaGeraProva.getTableHeader().getColumnModel().getColumn( 0 ).setMaxWidth( 0 );  
		tabelaDisciplinaGeraProva.getTableHeader().getColumnModel().getColumn( 0 ).setMinWidth( 0 );
		tabelaDisciplinaGeraProva.getColumnModel().getColumn(1).setPreferredWidth(300);
		tabelaDisciplinaGeraProva.setAutoResizeMode(0);
		
		tabelaDisciplinaGeraProva.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tabelaDisciplinaGeraProva.setShowGrid(false); // Ocultar as linhas da tabela
		tabelaDisciplinaGeraProva.setIntercellSpacing(new Dimension(0, 0)); //Ocultar os espa�os entre as c�lulas da tabela
		tabelaDisciplinaGeraProva.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				modeloTabelaConteudosGeraProva.getDataVector().removeAllElements();
				int linhaSelecionada = (int) tabelaDisciplinaGeraProva.getSelectedRow();
				int IdDisciplina = (int) tabelaDisciplinaGeraProva.getValueAt(linhaSelecionada, 0);
								
				List<Conteudo> lista = new ArrayList<Conteudo>();
				ConteudoDAO cDAO = new ConteudoDAO();
				
				try{
					lista = cDAO.listaConteudoDeUmaDisciplina(IdDisciplina);
					for(Conteudo c: lista){
						modeloTabelaConteudosGeraProva.addRow(new Object[] {c.getIdConteudo(), c.getNomeConteudo()});
					}
					
				}catch(SQLException e3){
					e3.printStackTrace();
				}
			}
		});
		scrollDisciplinaGeraProva.setViewportView(tabelaDisciplinaGeraProva);
		
		JLabel lblSelecioneOsContedos = new JLabel("Selecione o(s) conte\u00FAdo(s):");
		lblSelecioneOsContedos.setBounds(337, 70, 225, 14);
		painelProvaGerar.add(lblSelecioneOsContedos);
		
		JScrollPane scrollConteudosGeraProva = new JScrollPane();
		scrollConteudosGeraProva.setBounds(337, 95, 247, 149);
		painelProvaGerar.add(scrollConteudosGeraProva);
		
		tabelaConteudosGeraProva = new JTable(modeloTabelaConteudosGeraProva);
		tabelaConteudosGeraProva.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int linhaSelecionada = (int) tabelaConteudosGeraProva.getSelectedRow();
				
				int IdConteudo = (int) tabelaConteudosGeraProva.getValueAt(linhaSelecionada, 0);
				
				QuestoesSubjetivas qs = new QuestoesSubjetivas();
				
				QuestoesSubjetivasDAO qsDAO = new QuestoesSubjetivasDAO();
				List<QuestoesSubjetivas> lista = new ArrayList<>();
				
				try {
					lista = qsDAO.listaQuestoesSubjetivasPorConteudo(IdConteudo);
					
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
					
				for(int i=0; i<lista.size();i++){
					System.out.println(new Object[] {qs.getIdQSub(), qs.getEnunQSub(), qs.getDifQSub()});
				}
			
			}
		});
		
		tabelaConteudosGeraProva.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		scrollConteudosGeraProva.setViewportView(tabelaConteudosGeraProva);
		
		JLabel lblQuantidadeDeQuestes = new JLabel("Quest\u00F5es Subjetivas:");
		lblQuantidadeDeQuestes.setVerticalAlignment(SwingConstants.TOP);
		lblQuantidadeDeQuestes.setBounds(38, 270, 149, 20);
		painelProvaGerar.add(lblQuantidadeDeQuestes);
		
		JLabel lblQuantidadeDeQuestes_1 = new JLabel("Quest\u00F5es Objetivas:");
		lblQuantidadeDeQuestes_1.setVerticalAlignment(SwingConstants.TOP);
		lblQuantidadeDeQuestes_1.setBounds(38, 313, 170, 20);
		painelProvaGerar.add(lblQuantidadeDeQuestes_1);
		
		campoQuestoesObjGeraProva = new JTextField();
		campoQuestoesObjGeraProva.setBounds(171, 313, 55, 20);
		painelProvaGerar.add(campoQuestoesObjGeraProva);
		campoQuestoesObjGeraProva.setColumns(10);
		
		campoQuestoesSubGeraProva = new JTextField();
		campoQuestoesSubGeraProva.setBounds(171, 270, 55, 20);
		painelProvaGerar.add(campoQuestoesSubGeraProva);
		campoQuestoesSubGeraProva.setColumns(10);
		
		JButton btnAvanar = new JButton("Avan\u00E7ar");
		btnAvanar.setBounds(495, 352, 89, 23);
		painelProvaGerar.add(btnAvanar);
		
		painelQuestoesObjetivasGerenciar = new JPanel();
		frame.getContentPane().add(painelQuestoesObjetivasGerenciar, "name_566311266736518");
		painelQuestoesObjetivasGerenciar.setLayout(null);
		
		JLabel lblGerenciarQuestesObjetivas = new JLabel("Gerenciar Quest\u00F5es Objetivas");
		lblGerenciarQuestesObjetivas.setHorizontalAlignment(SwingConstants.CENTER);
		lblGerenciarQuestesObjetivas.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblGerenciarQuestesObjetivas.setBounds(171, 29, 273, 14);
		painelQuestoesObjetivasGerenciar.add(lblGerenciarQuestesObjetivas);
		
		JMenuBar barraDeMenu = new JMenuBar();
		frame.setJMenuBar(barraDeMenu);
		
		JMenu menuDisciplina = new JMenu("Disciplina");
		barraDeMenu.add(menuDisciplina);
		
		/*MENU DISCIPLINA -> CADASTRAR*/
		JMenuItem disciplinaAdicionar = new JMenuItem("Cadastrar");
		disciplinaAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eDisciplinaCadastrar) {
				/*Pain�is 6*/
				painelInicial.setVisible(false);
				painelDisciplinaGerenciar.setVisible(false);
				painelDisciplinaEditar.setVisible(false);
				painelConteudoCadastrar.setVisible(false);
				painelConteudoGerenciar.setVisible(false);
				painelQuestoesSubjetivasCadastrar.setVisible(false);
				painelQuestoesSubjetivasGerenciar.setVisible(false);
				painelProvaGerar.setVisible(false);
				painelAlternativasCadastrar.setVisible(false);
				painelQuestoesObjetivasCadastrar.setVisible(false);
				painelQuestoesObjetivasGerenciar.setVisible(false);
				painelDisciplinaCadastrar.setVisible(true);
				
				campoNomeDisciplina.setText("");
				campoNomeDisciplina.requestFocus();
			}
		});
		menuDisciplina.add(disciplinaAdicionar);
		
		/*MENU DISCIPLINA -> GERENCIAR*/
		JMenuItem disciplinaGerenciar = new JMenuItem("Gerenciar");
		disciplinaGerenciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eDisciplinaGerenciar) {
			
				/*Pain�is 7*/
				painelInicial.setVisible(false);
				painelDisciplinaCadastrar.setVisible(false);
				painelDisciplinaEditar.setVisible(false);
				painelConteudoCadastrar.setVisible(false);
				painelConteudoGerenciar.setVisible(false);
				painelQuestoesSubjetivasCadastrar.setVisible(false);
				painelQuestoesSubjetivasGerenciar.setVisible(false);
				painelAlternativasCadastrar.setVisible(false);
				painelQuestoesObjetivasCadastrar.setVisible(false);
				painelProvaGerar.setVisible(false);
				painelQuestoesObjetivasGerenciar.setVisible(false);
				painelDisciplinaGerenciar.setVisible(true);
				
				//Limpar tabela
				modeloTabelaDisciplinas.getDataVector().removeAllElements();
				
				//Descelecionar Itens
				tabelaDisciplinas.clearSelection();
				
				//Pegar disciplinas do BD
				
				List<Disciplina> listaDisciplina = new ArrayList<Disciplina>();
				DisciplinaDAO dDAO = new DisciplinaDAO();
				
				try{
					
					listaDisciplina = dDAO.listarDisciplinas();
					for(Disciplina d: listaDisciplina){
						modeloTabelaDisciplinas.addRow(new Object[] {d.getIdDisciplina(),d.getCodDisciplina(), d.getNomeDisciplina()});
					}
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		});
		menuDisciplina.add(disciplinaGerenciar);
		
		JMenu menuConteudo = new JMenu("Conte\u00FAdo");
		barraDeMenu.add(menuConteudo);
		
		/*MENU CONTE�DO -> CADASTRAR*/
		JMenuItem conteudoCadastrar = new JMenuItem("Cadastrar");
		conteudoCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eConteudoCadastrar) {
				
				DisciplinaDAO dDAO = new DisciplinaDAO();
				try{
					List<Disciplina> listaDisciplinas = new ArrayList<Disciplina>();
					listaDisciplinas = dDAO.listarDisciplinas();
					
					for(Disciplina d:listaDisciplinas ){
						modeloTabelaListaDisciplinas.addRow(new Object[] {d.getIdDisciplina(), d.getNomeDisciplina()});
					}
					
				}catch(SQLException e){
					e.printStackTrace();
				}
				/*Pain�is 8*/
				painelInicial.setVisible(false);
				painelDisciplinaCadastrar.setVisible(false);
				painelDisciplinaGerenciar.setVisible(false);
				painelDisciplinaEditar.setVisible(false);
				painelConteudoGerenciar.setVisible(false);
				painelQuestoesSubjetivasCadastrar.setVisible(false);
				painelQuestoesSubjetivasGerenciar.setVisible(false);
				painelAlternativasCadastrar.setVisible(false);
				painelProvaGerar.setVisible(false);
				painelQuestoesObjetivasCadastrar.setVisible(false);
				painelQuestoesObjetivasGerenciar.setVisible(false);
				painelConteudoCadastrar.setVisible(true);
				
				campoConteudo.setText("");
				campoConteudo.requestFocus();
			}
		});
		menuConteudo.add(conteudoCadastrar);
		
		/*MENU CONTE�DO -> GERENCIAR*/
		JMenuItem conteudoGerenciar = new JMenuItem("Gerenciar");
		conteudoGerenciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eventoGerenciarConteudo) {
				
				modeloTabelaGerenciarConteudo.getDataVector().removeAllElements();
				
				/*Pain�is 9*/
				painelInicial.setVisible(false);
				painelConteudoCadastrar.setVisible(false);
				painelDisciplinaCadastrar.setVisible(false);
				painelDisciplinaEditar.setVisible(false);
				painelDisciplinaGerenciar.setVisible(false);
				painelQuestoesSubjetivasCadastrar.setVisible(false);
				painelQuestoesSubjetivasGerenciar.setVisible(false);
				painelAlternativasCadastrar.setVisible(false);
				painelProvaGerar.setVisible(false);
				painelQuestoesObjetivasCadastrar.setVisible(false);
				painelQuestoesObjetivasGerenciar.setVisible(false);
				painelConteudoGerenciar.setVisible(true);
								
				tabelaGerenciarConteudo.clearSelection();
								
				ConteudoDAO cDAO = new ConteudoDAO();
				try{
					List<Conteudo> listaConteudo = new ArrayList<>();
					listaConteudo = cDAO.listaConteudo();
					
					for(Conteudo c: listaConteudo){
						modeloTabelaGerenciarConteudo.addRow(new Object[] {c.getIdConteudo(), c.getNomeConteudo(), c.getDisciplina()});
					}
				}catch(SQLException e){
					e.printStackTrace();
				}			
			}
		});
		menuConteudo.add(conteudoGerenciar);
		
		JMenu menuQustoes = new JMenu("Quest\u00F5es");
		barraDeMenu.add(menuQustoes);
		
		JMenu mnSubjetivas = new JMenu("Subjetivas");
		menuQustoes.add(mnSubjetivas);
		
		/*QUEST�ES SUBJETIVAS -> CADASTRAR*/
		JMenuItem mntmAdicionar = new JMenuItem("Cadastrar");
		mntmAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eventoQuestaoSubjetiva) {
				
				modelotabelaConteudoQuestoesSubjetivas.getDataVector().removeAllElements();
				/*Pain�is 10*/
				painelInicial.setVisible(false);
				painelDisciplinaCadastrar.setVisible(false);
				painelDisciplinaGerenciar.setVisible(false);
				painelDisciplinaEditar.setVisible(false);
				painelConteudoCadastrar.setVisible(false);
				painelConteudoGerenciar.setVisible(false);
				painelQuestoesSubjetivasGerenciar.setVisible(false);
				painelAlternativasCadastrar.setVisible(false);
				painelProvaGerar.setVisible(false);
				painelQuestoesObjetivasCadastrar.setVisible(false);
				painelQuestoesObjetivasGerenciar.setVisible(false);
				painelQuestoesSubjetivasCadastrar.setVisible(true);
				
				campoDescricaoQuestaoSubjetiva.setText("");
				campoDescricaoQuestaoSubjetiva.requestFocus();
				ConteudoDAO cDAO = new ConteudoDAO();
				
				try{
					List<Conteudo> listaConteudo = new ArrayList<>();
					listaConteudo = cDAO.listaConteudo();
					
					for(Conteudo c: listaConteudo){
						modelotabelaConteudoQuestoesSubjetivas.addRow(new Object[] {c.getIdConteudo(), c.getNomeConteudo(), c.getDisciplina()});
					}
					
				}catch(SQLException e){
					e.printStackTrace();
				}				
			}
		});
		mnSubjetivas.add(mntmAdicionar);
		
		JMenuItem mntmGerenciar = new JMenuItem("Gerenciar");
		mntmGerenciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/*Pain�is 11*/
				painelInicial.setVisible(false);
				painelDisciplinaCadastrar.setVisible(false);
				painelDisciplinaGerenciar.setVisible(false);
				painelDisciplinaEditar.setVisible(false);
				painelConteudoCadastrar.setVisible(false);
				painelConteudoGerenciar.setVisible(false);
				painelQuestoesSubjetivasCadastrar.setVisible(false);
				painelAlternativasCadastrar.setVisible(false);
				painelQuestoesObjetivasCadastrar.setVisible(false);
				painelProvaGerar.setVisible(false);
				painelQuestoesObjetivasGerenciar.setVisible(false);
				painelQuestoesSubjetivasGerenciar.setVisible(true);
			}
		});
		mnSubjetivas.add(mntmGerenciar);
		
		JMenu mnObjetivas = new JMenu("Objetivas");
		menuQustoes.add(mnObjetivas);
		
		JMenuItem mntmCadastrar = new JMenuItem("Cadastrar");
		mntmCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eCadastrarQObj) {
				/*Pain�is 11*/
				modelotabelaDiscContQuestaoObjetiva.getDataVector().removeAllElements();
				
				painelInicial.setVisible(false);
				painelDisciplinaCadastrar.setVisible(false);
				painelDisciplinaGerenciar.setVisible(false);
				painelDisciplinaEditar.setVisible(false);
				painelConteudoCadastrar.setVisible(false);
				painelConteudoGerenciar.setVisible(false);
				painelQuestoesSubjetivasCadastrar.setVisible(false);
				painelQuestoesSubjetivasGerenciar.setVisible(false);
				painelAlternativasCadastrar.setVisible(false);
				painelQuestoesObjetivasGerenciar.setVisible(false);
				painelQuestoesObjetivasCadastrar.setVisible(true);
				
				campoQuestaoObjetiva.setText("");
				campoQuestaoObjetiva.requestFocus();
				
				ConteudoDAO cDAO = new ConteudoDAO();
				
				try{
					List<Conteudo> listaConteudo = new ArrayList<>();
					listaConteudo = cDAO.listaConteudo();
					
					for(Conteudo c: listaConteudo){
						modelotabelaDiscContQuestaoObjetiva.addRow(new Object[] {c.getIdConteudo(), c.getNomeConteudo(), c.getDisciplina()});
					}
					
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
		});
		mnObjetivas.add(mntmCadastrar);
		
		JMenuItem mntmGerenciar_1 = new JMenuItem("Gerenciar");
		mntmGerenciar_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent eventoGerenciarQObj) {
				/*Pain�is 12*/
				
				painelInicial.setVisible(false);
				painelDisciplinaCadastrar.setVisible(false);
				painelDisciplinaGerenciar.setVisible(false);
				painelDisciplinaEditar.setVisible(false);
				painelConteudoCadastrar.setVisible(false);
				painelConteudoGerenciar.setVisible(false);
				painelQuestoesSubjetivasCadastrar.setVisible(false);
				painelQuestoesSubjetivasGerenciar.setVisible(false);
				painelAlternativasCadastrar.setVisible(false);
				painelQuestoesObjetivasCadastrar.setVisible(false);
				painelQuestoesObjetivasGerenciar.setVisible(true);
			}
		});
		mnObjetivas.add(mntmGerenciar_1);
		
		JMenu mnProva = new JMenu("Prova");
		barraDeMenu.add(mnProva);
		
		JMenuItem mntmGerar = new JMenuItem("Gerar");
		mntmGerar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/*Pain�is 13*/
				modelotabelaDisciplinaGeraProva.getDataVector().removeAllElements();
				modeloTabelaConteudosGeraProva.getDataVector().removeAllElements();
				
				painelInicial.setVisible(false);
				painelDisciplinaCadastrar.setVisible(false);
				painelDisciplinaGerenciar.setVisible(false);
				painelDisciplinaEditar.setVisible(false);
				painelConteudoCadastrar.setVisible(false);
				painelConteudoGerenciar.setVisible(false);
				painelQuestoesSubjetivasCadastrar.setVisible(false);
				painelQuestoesSubjetivasGerenciar.setVisible(false);
				painelAlternativasCadastrar.setVisible(false);
				painelQuestoesObjetivasCadastrar.setVisible(false);
				painelQuestoesObjetivasGerenciar.setVisible(false);
				painelProvaGerar.setVisible(true);
				
				//Disciplina d = new Disciplina();
				
				DisciplinaDAO dDAO = new DisciplinaDAO();
				
				try{
					List<Disciplina> listaDisciplina = new ArrayList<Disciplina>();
					listaDisciplina = dDAO.listarDisciplinas();
					
					for(Disciplina d: listaDisciplina){
						modelotabelaDisciplinaGeraProva.addRow(new Object[] {d.getIdDisciplina(), d.getNomeDisciplina()});
					}
				}catch(SQLException e1){
					e1.printStackTrace();
				}
				
			}
		});
		mnProva.add(mntmGerar);
	}
}
